<x-masterLayout.master>
    @section("title")
        {{ __("global.products",[],session("lang")) }}
    @endsection
    @section("recycle_bin")
        <a class="dropdown-item" href="{{route("product.viewRecyclebin")}}">
            <i class="fas fa-trash fa-sm fa-fw mr-2 text-gray-400"></i>
            {{__("global.recycle_bin",["attribute"=>__("global.products",[],session("lang"))],session("lang"))}}
        </a>
    @endsection

    @section('content')
        @section("id"){{\App\Models\Product::withTrashed()->selectRaw("max(id) as id")->first()->id + 1}}@endsection

        <div class="container">
            @if(auth()->user()->getConfig("add_method") != "modal")

                <div class="row">
                    <div class="bg-gray-100 card o-hidden border-0 shadow-lg p-4 col-lg-3 col-sm-12">
                        <form action="{{route("product.storeProduct")}}" method="POST"  accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off">
                            @csrf
                            <x-forms.products-form></x-forms.products-form>
                            <input id="btn_add" class="btn btn-primary btn-block" type="submit" value="{{__("global.create",[],session("lang"))}}">
                        </form>
                    </div>

                    <div class="col-sm-0 col-lg-1"></div>

                    <div class="col-lg-8 col-sm-12">
        @else
            <div>
                <div>
                    <div class="form-group">
                        <a id="btn_add" title="{{__("global.add",[],session("lang"))}}" class="btn btn-sm btn-info" href="#" data-toggle="modal" data-target="#addModal" data-route="{{route("product.storeProduct")}}">
                            <i class="fas fa-plus"></i>
                            {{__("global.add",[],session("lang"))}}
                        </a>
                    </div>
        @endif
                    <div class="card shadow">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">{{__("global.products",[],session("lang"))}}</h6>
                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                <table class="table table-bordered table-striped" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>{{__("global.id",[],session("lang"))}}</th>
                                            <th>{{__("global.name",[],session("lang"))}}</th>
                                            <th>{{__("global.type",[],session("lang"))}}</th>
                                            <th>{{__("global.reference",[],session("lang"))}}</th>
                                            <th>{{__("global.store",[],session("lang"))}}</th>
                                            <th>{{__("global.delete",[],session("lang"))}}</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                        @foreach ($products as $product)

                                            <tr>
                                                <td>{{$product->id}}</td>
{{--                                                <td><a href={{route("product.showProduct",$product)}}>{{$product->name}}</a></td>--}}
                                                <td>{{$product->name}}</td>
                                                <td>{{$product->account_type}}</td>
                                                <td>{{$product->reference}}</td>
                                                <td>{{$product->store->name}}</td>
                                                <td class="row m-0">
                                                    <a id="btn_update" title="{{__("global.update",[],session("lang"))}}" class="dropdown-item col-7 m-0 p-0" href="#" data-toggle="modal" data-target="#updateModal" data-fields="{{$product}}" data-route="{{route("product.updateProduct",$product->id)}}">
                                                        <input class="grid-button grid-edit-button" type="button" title="Update">
                                                    </a>
                                                    <a id="btn_delete" title="{{__("global.delete",[],session("lang"))}}" class="dropdown-item col-5 m-0 p-0" href="#" data-toggle="modal" data-target="#deleteConfirmModal" @if(auth()->user()->getConfig("use_recyclebin") == "true") data-route="{{route("product.softDeleteProduct",$product->id)}}" @else data-route="{{route("product.deleteProduct",$product->id)}}"  @endif>
                                                        <input class="grid-button grid-delete-button" type="button" title="Delete">
                                                    </a>
                                                </td>
                                            </tr>
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    @endsection
    @section("modals")
        <x-modals.delete-confirm-modal></x-modals.delete-confirm-modal>
        @if(auth()->user()->getConfig("add_method") == "modal")
            <x-modals.add-modal :modelName="$modelName = 'product'"></x-modals.add-modal>
        @endif
        <x-modals.update-modal :modelName="$modelName = 'product'"></x-modals.update-modal>

    @endsection
    @section("script")

    @endsection
</x-masterLayout.master>








