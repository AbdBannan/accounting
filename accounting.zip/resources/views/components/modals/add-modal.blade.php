<!-- add Modal-->
<div class="modal fade" id="addModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__("global.add",[],session("lang"))}}</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form_add" action="" method="POST" accept-charset="UTF-8" enctype="multipart/form-data" autocomplete="off">
                    @csrf
                    @if($modelName == "account")
                        <x-forms.accounts-form></x-forms.accounts-form>
                    @elseif($modelName == "product")
                        <x-forms.products-form></x-forms.products-form>
                    @elseif($modelName == "category")
                        <x-forms.categories-form></x-forms.categories-form>
                    @elseif($modelName == "store")
                        <x-forms.stores-form></x-forms.stores-form>
                    @elseif($modelName == "role")
                        <x-forms.roles-form></x-forms.roles-form>
                    @elseif($modelName == "permission")
                        <x-forms.permissions-form></x-forms.permissions-form>
                    @elseif($modelName == "pound")
                        <x-forms.pounds-form></x-forms.pounds-form>

                    @endif

                </form>
            </div>
            <div class="modal-footer">
                <div class="form-group">
                    <input id="btn_id" form="form_add" class="btn btn-primary" type="submit" value="{{__("global.add",[],session("lang"))}}">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">{{__("global.cancel",[],session("lang"))}}</button>
                </div>
            </div>
        </div>
    </div>
</div>




{{--                <form id="form_update" action="" method="POST" accept-charset="UTF-8" enctype="multipart/form-data">--}}
{{--                    {{csrf_field()}}--}}
{{--                    <input type="hidden" name="_method" value="PUT">--}}
{{--                    @foreach($fields as $field)--}}

{{--                        @if($field["type"] == 'text')--}}
{{--                            <div class="form-group">--}}
{{--                                <label for="{{$field["label"]}}">{{__("global.".$field['label'],[],session("lang"))}}</label>--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="text" value="asldfjlsk" class="form-control" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'email')--}}
{{--                            <div class="form-group">--}}
{{--                                <label for="{{$field["label"]}}">{{__("global.".$field['label'],[],session("lang"))}}</label>--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="email" class="form-control" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'file')--}}
{{--                            <div class="form-group">--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="file" class="form-control-file" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'textarea')--}}
{{--                            <div class="form-group">--}}
{{--                                <label for="{{$field["label"]}}">{{__("global.".$field['label'],[],session("lang"))}}</label>--}}
{{--                                <textarea id="{{$field["label"]}}" name="{{$field["label"]}}" class="form-control" cols="50" rows="5" {{$field["extra"]}}></textarea>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'select')--}}
{{--                            <div class="form-group">--}}
{{--                                <select id="{{$field["label"]}}" name="{{$field["label"]}}" class="form-control" {{$field["extra"]}}>--}}
{{--                                    @foreach($field["options"] as $option)--}}
{{--                                        <option>{{__("global.".$option,[],session("lang"))}}</option>--}}
{{--                                    @endforeach--}}
{{--                                </select>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'number')--}}
{{--                            <div class="form-group">--}}
{{--                                <label for="{{$field["label"]}}">{{__("global.".$field['label'],[],session("lang"))}}</label>--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="number" class="form-control" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'range')--}}
{{--                            <div class="form-group">--}}
{{--                                <label for="{{$field["label"]}}">{{__("global.".$field['label'],[],session("lang"))}}</label>--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="range" class="form-control-range" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'checkbox')--}}
{{--                            <div class="form-group">--}}
{{--                                @foreach($field["values"] as $label)--}}
{{--                                    <div class="form-check">--}}
{{--                                        <label class="form-check-label">--}}
{{--                                            <input id="{{$label}}" name="{{$label}}" type="checkbox" value="{{$label}}" class="form-check-input">--}}
{{--                                            {{__("global.".$label,[],session("lang"))}}--}}
{{--                                        </label>--}}
{{--                                    </div>--}}
{{--                                @endforeach--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'radio')--}}
{{--                            <div class="form-group">--}}
{{--                                <fieldset id="group1">--}}
{{--                                    @foreach($field["values"] as $label)--}}
{{--                                        <div class="form-check">--}}
{{--                                            <label class="form-check-label">--}}
{{--                                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="radio" class="form-check-input" value="{{$label}}" ="aaa" checked="">--}}
{{--                                                {{__("global.".$label,[],session("lang"))}}--}}
{{--                                            </label>--}}
{{--                                        </div>--}}
{{--                                    @endforeach--}}
{{--                                </fieldset>--}}

{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'color')--}}
{{--                            <div class="form-group">--}}
{{--                                <input id="{{$field["label"]}}" name="{{$field["label"]}}" type="color" class="form-control-color" {{$field["extra"]}}>--}}
{{--                            </div>--}}
{{--                        @elseif($field["type"] == 'submit')--}}
{{--                            <div class="form-group">--}}
{{--                                <input class="btn btn-primary" type="{{$field["type"]}}" value="{{$field["label"]}}" {{__("global.".$field["extra"],[],session("lang"))}}>--}}
{{--                                <button class="btn btn-secondary" type="button" data-dismiss="modal">{{__("global.cancel",[],session("lang"))}}</button>--}}
{{--                            </div>--}}
{{--                        @endif--}}
{{--                    @endforeach--}}

{{--                </form>--}}
