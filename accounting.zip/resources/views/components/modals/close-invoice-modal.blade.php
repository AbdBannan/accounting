<!-- close invoice Modal-->
<div class="modal fade" id="closingDateModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">{{__("global.closing_date",[],session("lang"))}}</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="form-group">
                    <input form="form" type="date" id="closing_date" name="closing_date"  class="form-control" value="{{Carbon\Carbon::now()->toDateString("mm/dd/yyyy")}}" autofocus>
                </div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">{{__("global.cancel",[],session("lang"))}}</button>
                <input id="btn-submit-invoice" form="form" class="btn btn-success" type="submit" value="{{__("global.save",[],session("lang"))}}">
            </div>
        </div>
    </div>
</div>
