<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'failed' => 'المعلومات المزودة لا تطابق المعلومات الصحيحة',
    'password' => 'كلمة السر غير صحيحة',
    'throttle' => 'محاولات تسجيل دخول متكررة , الرجاء المحاولة بعد :seconds ثانية.',

];
